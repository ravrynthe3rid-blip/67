package com.wisp;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

public record SummonPayload(String mobId) implements CustomPacketPayload {
    public static final Type<SummonPayload> TYPE =
            new Type<>(Identifier.fromNamespaceAndPath(Wisp.MOD_ID, "summon"));
    public static final StreamCodec<ByteBuf, SummonPayload> CODEC =
            ByteBufCodecs.STRING_UTF8.map(SummonPayload::new, SummonPayload::mobId);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
