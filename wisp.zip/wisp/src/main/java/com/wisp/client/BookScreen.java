package com.wisp.client;

import com.wisp.SummonPayload;
import com.wisp.item.BookOfKnowledgeItem;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.StringWidget;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.EntityType;

/** Paged list of every mob; click a name to summon it (costs 10-400 XP). */
public class BookScreen extends Screen {
    private static final int COLS = 2, ROWS = 8, PER_PAGE = COLS * ROWS;
    private static List<EntityType<?>> MOBS;
    private int page = 0;

    public BookScreen() {
        super(Component.literal("Book of Knowledge"));
        if (MOBS == null) {
            MOBS = new ArrayList<>();
            for (EntityType<?> t : BuiltInRegistries.ENTITY_TYPE) {
                if (BookOfKnowledgeItem.isSummonable(t)) MOBS.add(t);
            }
            MOBS.sort(Comparator.comparing(t -> t.getDescription().getString()));
        }
    }

    @Override
    protected void init() {
        int pages = (MOBS.size() + PER_PAGE - 1) / PER_PAGE;
        int bw = Math.min(150, (this.width - 30) / COLS);
        int left = this.width / 2 - (bw * COLS + 4) / 2;
        int top = 34;

        this.addRenderableWidget(new StringWidget(0, 12, this.width, 12,
                Component.literal("Book of Knowledge - page " + (page + 1) + "/" + pages), this.font));

        int start = page * PER_PAGE;
        for (int i = 0; i < PER_PAGE && start + i < MOBS.size(); i++) {
            EntityType<?> type = MOBS.get(start + i);
            int x = left + (i % COLS) * (bw + 4);
            int y = top + (i / COLS) * 22;
            this.addRenderableWidget(Button.builder(type.getDescription(), b -> {
                ClientPlayNetworking.send(new SummonPayload(BuiltInRegistries.ENTITY_TYPE.getKey(type).toString()));
                this.onClose();
            }).bounds(x, y, bw, 20).build());
        }

        int ny = Math.min(this.height - 28, top + ROWS * 22 + 6);
        this.addRenderableWidget(Button.builder(Component.literal("<"), b -> { page--; rebuildWidgets(); })
                .bounds(this.width / 2 - 70, ny, 40, 20).build()).active = page > 0;
        this.addRenderableWidget(Button.builder(Component.literal("Close"), b -> this.onClose())
                .bounds(this.width / 2 - 25, ny, 50, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal(">"), b -> { page++; rebuildWidgets(); })
                .bounds(this.width / 2 + 30, ny, 40, 20).build()).active = page < pages - 1;
    }
}
