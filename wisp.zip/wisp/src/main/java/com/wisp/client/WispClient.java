package com.wisp.client;

import com.wisp.item.BookOfKnowledgeItem;
import net.fabricmc.api.ClientModInitializer;
import net.minecraft.client.Minecraft;

public class WispClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        BookOfKnowledgeItem.OPEN_SCREEN = () -> Minecraft.getInstance().setScreen(new BookScreen());
    }
}
