package com.wisp;

import com.wisp.item.BookOfKnowledgeItem;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;

public class Wisp implements ModInitializer {
    public static final String MOD_ID = "wisp";

    @Override
    public void onInitialize() {
        ModItems.init();

        PayloadTypeRegistry.playC2S().register(SummonPayload.TYPE, SummonPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(SummonPayload.TYPE,
                (payload, context) -> BookOfKnowledgeItem.handleSummon(context.player(), payload.mobId()));

        // Fractured: Haste V + Speed II while held
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (ServerPlayer p : server.getPlayerList().getPlayers()) {
                if (p.getMainHandItem().is(ModItems.FRACTURED) || p.getOffhandItem().is(ModItems.FRACTURED)) {
                    p.addEffect(new MobEffectInstance(MobEffects.HASTE, 10, 4, true, false, false));
                    p.addEffect(new MobEffectInstance(MobEffects.SPEED, 10, 1, true, false, false));
                }
            }
        });

        // Bedrock / end portal frames normally drop nothing; give them back
        PlayerBlockBreakEvents.AFTER.register((level, player, pos, state, be) -> {
            if (!level.isClientSide() && player.getMainHandItem().is(ModItems.FRACTURED)
                    && (state.is(net.minecraft.world.level.block.Blocks.BEDROCK)
                    || state.is(net.minecraft.world.level.block.Blocks.END_PORTAL_FRAME))) {
                Block.popResource(level, pos, new ItemStack(state.getBlock()));
            }
        });
    }
}
