package com.wisp;

import com.wisp.item.BookOfKnowledgeItem;
import com.wisp.item.DilationItem;
import com.wisp.item.DivisionItem;
import java.util.function.Function;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ToolMaterial;

public final class ModItems {
    public static final Item DIVISION = register("division", p -> new DivisionItem(p.stacksTo(1)));
    public static final Item DILATION = register("dilation", p -> new DilationItem(p.stacksTo(1)));
    public static final Item FRACTURED = register("fractured",
            p -> new Item(p.pickaxe(ToolMaterial.NETHERITE, 1.0F, -2.8F)));
    public static final Item BOOK_OF_KNOWLEDGE = register("book_of_knowledge",
            p -> new BookOfKnowledgeItem(p.stacksTo(1)));

    private static Item register(String name, Function<Item.Properties, Item> factory) {
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath(Wisp.MOD_ID, name));
        return Registry.register(BuiltInRegistries.ITEM, key, factory.apply(new Item.Properties().setId(key)));
    }

    public static void init() {
        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.TOOLS_AND_UTILITIES).register(e -> {
            e.accept(DIVISION);
            e.accept(DILATION);
            e.accept(FRACTURED);
            e.accept(BOOK_OF_KNOWLEDGE);
        });
    }
}
