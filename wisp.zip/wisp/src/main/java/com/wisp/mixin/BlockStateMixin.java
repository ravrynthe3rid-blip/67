package com.wisp.mixin;

import com.wisp.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockBehaviour;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Lets the Fractured pickaxe mine unbreakable blocks (bedrock, end portal frames). */
@Mixin(BlockBehaviour.BlockStateBase.class)
public abstract class BlockStateMixin {
    @Shadow public abstract boolean is(Block block);

    @Inject(method = "getDestroyProgress", at = @At("HEAD"), cancellable = true)
    private void wisp$fractured(Player player, BlockGetter level, BlockPos pos, CallbackInfoReturnable<Float> cir) {
        if (player.getMainHandItem().is(ModItems.FRACTURED) && (is(Blocks.BEDROCK) || is(Blocks.END_PORTAL_FRAME))) {
            cir.setReturnValue(0.2F);
        }
    }
}
