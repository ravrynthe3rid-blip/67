package com.wisp.item;

import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;

/** Right-click toggles slowed time (server tick rate 20 -> 5). */
public class DivisionItem extends Item {
    public DivisionItem(Properties props) { super(props); }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        if (!level.isClientSide()) {
            MinecraftServer server = level.getServer();
            boolean slowed = server.tickRateManager().tickrate() < 20.0F;
            server.tickRateManager().setTickRate(slowed ? 20.0F : 5.0F);
            player.displayClientMessage(Component.literal(slowed ? "Time flows normally" : "Time slows..."), true);
        }
        return InteractionResult.SUCCESS;
    }
}
