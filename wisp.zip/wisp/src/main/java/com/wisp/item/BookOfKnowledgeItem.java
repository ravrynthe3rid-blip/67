package com.wisp.item;

import com.wisp.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;

public class BookOfKnowledgeItem extends Item {
    /** Set by the client initializer; opens the mob-list screen. */
    public static Runnable OPEN_SCREEN = null;

    public BookOfKnowledgeItem(Properties props) { super(props); }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        if (level.isClientSide() && OPEN_SCREEN != null) OPEN_SCREEN.run();
        return InteractionResult.SUCCESS;
    }

    public static boolean isSummonable(EntityType<?> t) {
        return t.canSummon() && t.getCategory() != MobCategory.MISC;
    }

    public static void handleSummon(ServerPlayer player, String id) {
        if (!player.getMainHandItem().is(ModItems.BOOK_OF_KNOWLEDGE)
                && !player.getOffhandItem().is(ModItems.BOOK_OF_KNOWLEDGE)) return;
        Identifier key = Identifier.tryParse(id);
        if (key == null) return;
        EntityType<?> type = BuiltInRegistries.ENTITY_TYPE.getOptional(key).orElse(null);
        if (type == null || !isSummonable(type)) return;
        if (!(player.level() instanceof ServerLevel level)) return;

        int cost = player.getRandom().nextIntBetweenInclusive(10, 400);
        boolean free = player.isCreative();
        if (!free && player.totalExperience < cost) {
            player.displayClientMessage(Component.literal("Not enough experience: needs " + cost + " XP"), true);
            return;
        }
        BlockPos pos = BlockPos.containing(player.position().add(player.getLookAngle().scale(2.5)));
        if (type.spawn(level, pos, EntitySpawnReason.COMMAND) == null) return;
        if (!free) player.giveExperiencePoints(-cost);
        player.displayClientMessage(Component.literal("Summoned " + type.getDescription().getString()
                + (free ? "" : " (-" + cost + " XP)")), true);
    }
}
