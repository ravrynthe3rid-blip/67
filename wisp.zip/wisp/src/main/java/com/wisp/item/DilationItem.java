package com.wisp.item;

import java.util.Set;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Relative;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.FishingRodItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;

/** Right-click a player or mob to swap places with it. */
public class DilationItem extends FishingRodItem {
    public DilationItem(Properties props) { super(props); }

    @Override
    public InteractionResult interactLivingEntity(ItemStack stack, Player player, LivingEntity target, InteractionHand hand) {
        if (player.level() instanceof ServerLevel level && target.level() == level) {
            Vec3 a = player.position();
            Vec3 b = target.position();
            player.teleportTo(level, b.x, b.y, b.z, Set.<Relative>of(), player.getYRot(), player.getXRot(), true);
            target.teleportTo(level, a.x, a.y, a.z, Set.<Relative>of(), target.getYRot(), target.getXRot(), true);
            player.getCooldowns().addCooldown(stack, 20);
        }
        return InteractionResult.SUCCESS;
    }
}
